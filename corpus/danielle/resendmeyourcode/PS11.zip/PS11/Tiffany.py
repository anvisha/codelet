# Problem Set 11 - Clustering Counties
# Name: Tiffany Hood
# Collaborators:
# Time:

#Code shared across examples
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import pylab, random, string, copy, math
from cluster import *
from cvisualization import *


# US Counties example
def readCountyData(fName, numEntries = 14):
    '''
    Reads in county data, with 14 feature vectors, from
    file fName.
    '''
    dataFile = open(fName, 'r')
    dataList = []
    nameList = []
    maxVals = pylab.array([0.0]*numEntries)
    #Build unnormalized feature vector
    for line in dataFile:
        if len(line) == 0 or line[0] == '#':
            continue
        dataLine = string.split(line)
        name = dataLine[0] + dataLine[1]
        features = []
        #Build vector with numEntries features
        for f in dataLine[2:]:
            try:
                f = float(f)
                features.append(f)
            except ValueError:
                name = name + f

        # if we've found a bad line....
        if len(features) != numEntries:
            continue
        dataList.append(features)
        nameList.append(name)
        for i in range(len(features)):
            if features[i] > maxVals[i]:
                maxVals[i] = features[i]        

    return nameList, dataList, maxVals
    
def buildCountyPoints(fName):
    """
    Given an input filename, reads County values from the file and returns
    them all in a list.
    """
    nameList, featureList, maxVals = readCountyData(fName)
    points = []
    for i in range(len(nameList)):
        originalAttrs = pylab.array(featureList[i])
        normalizedAttrs = originalAttrs/pylab.array(maxVals)
        points.append(County(nameList[i], originalAttrs, normalizedAttrs))
    return points

def getAveIncome(cluster):
    """
    Given a Cluster object, finds the average income field over the members
    of that cluster.
    
    cluster: the Cluster object to check
    
    Returns: a float representing the computed average income value
    """
    tot = 0.0
    numElems = 0
    for c in cluster.getPoints():
        tot += c.getOriginalAttr(County.Income)

    return float(tot) / len(cluster.getPoints())


def test(points, k = 200, cutoff = 0.1):
    """
    A sample function to show you how to do a simple kmeans run and graph
    the results.
    """
    incomes = []
    print ''
    clusters, maxSmallest = kmeans(points, k, cutoff, County)

    for clustNum in range(k):
        if len(clusters[clustNum].points) == 0:
            continue
        incomes.append(getAveIncome(clusters[clustNum]))

    pylab.hist(incomes)
    pylab.xlabel('Ave. Income')
    pylab.ylabel('Number of Clusters')
    pylab.show()

        
# Problem 1: Implement k-means in cluster.py
# Run the test function on the testPoints.

# points contains the _entire_ dataset
points = buildCountyPoints('counties.txt')
# testPoints contains but a tenth of them.
testPoints = random.sample(points, len(points)/10)


# Problem 2: Visualizing k-means

def visualizeClusters():
    '''
    Zeros out all but two of the dimensions in the County feature
    vector.

    Then, makes an appropriate call to visual_kmeans using the County
    testPoints dataset.
    
    Takes no parameters (necessary for the animation to work)
    '''
    #set all of the weights to zero
    County.equal_weights(0.0)
    #set two of the features weights to 1.0
    County.set_weight(County.Income, 1.0)
    County.set_weight(County.Poverty, 1.0)

    visual_kmeans(figure, subplot, testPoints, 6, County, County.Income, County.Poverty)
    


# ******** Animation Code *************
figure = plt.figure()
subplot = figure.add_subplot(111)
## Uncomment the following 2 lines when you've defined visualizeClusters:
figure.canvas.manager.window.after(100, visualizeClusters)
plt.show()


# Problem 3: k-means and Individual Counties

def findCountyCluster(points, county, k, cutoff = 0.1):
    '''
    Runs k-means clustering over points 3 times with the given k 
    and cutoff values. Each time the clustering is run, this function
    prints out the cluster that contains the specified county.

    points: a list of Point objects
    county: a string, the county we wish to examine
    k: int, the number of clusters we wish to use
    cutoff: float     
    '''
    County.equal_weights(0)
    County.set_weight(County.FarmAcres, 1.0)
    County.set_weight(County.PopDensity, 0.5) 
    for t in range(3):
        (clusters, diameter) = kmeans(points, k, cutoff, County)
        for c in clusters:
            #see if specific county is in cluster and print the cluster if it is
            if c.contains(county)==True:
                break
            else:
                continue

           
            


# Problem 4: Predicting Percentage of College Graduates with k-means

def graphPredictionErr(points, kvals, cutoff = 0.1):
    """    
    Given input points and a list of kvals, should cluster on the
    appropriate weight vectors and graph the error in the resulting
    predictions, as described in Problem 4.

    points: a list of Point objects
    kvals: a list of k values (integers)
    cutoff: float     
    """
    kvals = range(10, 75, 10)
    
    County.equal_weights(0)
    County.set_weight(County.Income, 1.0)
    County.set_weight(County.Poverty, 1.0)
    County.set_weight(County.Unemployed, 1.0)
    County.set_weight(County.HomeValue, 1.0)
    County.set_weight(County.PrcntHSgrads, 1.0)

    goodCV = []
    for k in kvals:
        goodCVSum = 0
        (clusters, diameter) = kmeans(points, k, cutoff, County)
        for cluster in clusters:
            goodPoints = cluster.getPoints()
            goodCVSum+=(calCV(goodPoints, County.PrcntCollege))
        goodCV.append(float(goodCVSum)/k)



    County.equal_weights(0)
    County.set_weight(County.Prcnt65, 1.0)
    County.set_weight(County.Below18, 1.0)
    County.set_weight(County.LifeExpectancy, 1.0)
    County.set_weight(County.PrcntBelow18, 1.0)
    County.set_weight(County.PopChange, 1.0)

    badCV = []
    for k in kvals:
        badCVSum = 0
        (clusters, diameter) = kmeans(points, k, cutoff, County)
        for cluster in clusters:
            badPoints = cluster.getPoints()
            badCVSum+=(calCV(badPoints, County.PrcntCollege))
        badCV.append(float(badCVSum)/k)



    plotGood, = pylab.plot(kvals, goodCV)
    plotBad, = pylab.plot(kvals, badCV)
    pylab.legend(('Good Features', 'Bad Feastures'))
    pylab.title('kvals vs. CV')
    pylab.xlabel('kvals')
    pylab.ylabel('CV')
    pylab.show()
    

def calCV (points, dimension):
    global PrcntCollege
    pointVal = []
    for point in points:
        pointVal.append(point.getOriginalAttr(dimension))
    sumDimen = sum(pointVal)
    mean = sumDimen/len(pointVal)
    pointVar = 0.0
    for val in pointVal:
        pointVar += (val - mean)**2
    stanDev = math.sqrt(pointVar/len(pointVal))
    return stanDev/mean


