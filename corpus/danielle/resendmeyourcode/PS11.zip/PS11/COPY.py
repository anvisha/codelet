# Problem Set 11 - Clustering Counties
# Name:Hilary Mulholland
# Collaborators:Jackie Brew
# Time:10 hours
# Late Days Used: 3

#Code shared across examples
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import pylab, random, string, copy, math
from cluster import *
from cvisualization import *


# US Counties example
def readCountyData(fName, numEntries = 14):
    '''
    Reads in county data, with 14 feature vectors, from
    file fName.
    '''
    dataFile = open(fName, 'r')
    dataList = []
    nameList = []
    maxVals = pylab.array([0.0]*numEntries)
    #Build unnormalized feature vector
    for line in dataFile:
        if len(line) == 0 or line[0] == '#':
            continue
        dataLine = string.split(line)
        name = dataLine[0] + dataLine[1]
        features = []
        #Build vector with numEntries features
        for f in dataLine[2:]:
            try:
                f = float(f)
                features.append(f)
            except ValueError:
                name = name + f

        # if we've found a bad line....
        if len(features) != numEntries:
            continue
        dataList.append(features)
        nameList.append(name)
        for i in range(len(features)):
            if features[i] > maxVals[i]:
                maxVals[i] = features[i]        

    return nameList, dataList, maxVals
    
def buildCountyPoints(fName):
    """
    Given an input filename, reads County values from the file and returns
    them all in a list.
    """
    nameList, featureList, maxVals = readCountyData(fName)
    points = []
    for i in range(len(nameList)):
        originalAttrs = pylab.array(featureList[i])
        normalizedAttrs = originalAttrs/pylab.array(maxVals)
        points.append(County(nameList[i], originalAttrs, normalizedAttrs))
    return points

def getAveIncome(cluster):
    """
    Given a Cluster object, finds the average income field over the members
    of that cluster.
    
    cluster: the Cluster object to check
    
    Returns: a float representing the computed average income value
    """
    tot = 0.0
    numElems = 0
    for c in cluster.getPoints():
        tot += c.getOriginalAttr(County.Income)

    return float(tot) / len(cluster.getPoints())


def test(points, k = 200, cutoff = 0.1):
    """
    A sample function to show you how to do a simple kmeans run and graph
    the results.
    """
    incomes = []
    print ''
    clusters, maxSmallest = kmeans(points, k, cutoff, County)

    for clustNum in range(k):
        if len(clusters[clustNum].points) == 0:
            continue
        incomes.append(getAveIncome(clusters[clustNum]))

    pylab.hist(incomes)
    pylab.xlabel('Ave. Income')
    pylab.ylabel('Number of Clusters')
    pylab.show()

        
# Problem 0: Read through and understand cluster.py and the above code.
# Run the test function on the testPoints.

# points contains the _entire_ dataset
points = buildCountyPoints('counties.txt')
# testPoints contains but a tenth of them.
testPoints = random.sample(points, len(points)/10)


# Problem 1: Visualizing k-means

def visualizeClusters():
    '''
    Zeros out all but two of the dimensions in the County feature
    vector.

    Then, makes an appropriate call to visual_kmeans using the County
    testPoints dataset.
    
    Takes no parameters (necessary for the animation to work)
    '''

    #buildCountyPoints('counties.txt')
    County.equal_weights(0)
    County.set_weight(County.PrcntHSgrads, 1.0)
    County.set_weight(County.PrcntCollege, 1.0)

    visual_kmeans(figure, subplot, testPoints, 6, County, County.PrcntHSgrads, County.PrcntCollege,delay=1, cutoff=0.01, minIters = 3, maxIters = 100)
    #pointType is equal to county
   


# ******** Animation Code *************
figure = plt.figure()
subplot = figure.add_subplot(111)
## Uncomment the following 2 lines when you've defined visualizeClusters:
#figure.canvas.manager.window.after(100, visualizeClusters)
#plt.show()


# Problem 2: Choosing k


def graphRemovedErr(points, kvals, numTrials, cutoff = 0.1):
    """
    Should produce graphs of the average error in training and 
    holdout sets over the provided range of kvals, as described
    in Problem 2.

    points: a list of Point objects
    kvals: a list of k values (integers)
    numTrials: the number of trials to repeat
    cutoff: float
    """
    County.equal_weights(0)
    County.set_weight(County.PrcntHSgrads, 1.0)
    County.set_weight(County.PrcntCollege, 1.0)

    (trainingPoints,holdoutPoints)=randomPartition(points,.8)
    #this makes it so that 80% of the data goes to the training set

    for trial in range(numTrials):
        holdoutsetavg=[]
        trainingsetavg=[]
        for k in kvals:
            avgTotalErrorHoldout=0
            trainingErrorSum=0
            (clusterList, diameter)=kmeans(trainingPoints, k, cutoff, County, minIters = 3, maxIters = 100, toPrint = True)
            #cutoff is not defined here because it is given in graphRemovedErr
            for cluster in clusterList:
                center=cluster.getCentroid()#this gets the cluster's center
                for points in cluster.getPoints():
                    trainingErrorSum+=(points.distance(center))**2
            trainingsetavg.append(float(trainingErrorSum)/len(trainingPoints))
            for point in holdoutPoints:
                bestCenter=clusterList[0].getCentroid()
                #this makes it so we set the first cluster to be the best
                smallestDistance=point.distance(bestCenter)
                for cluster in clusterList[1:]:
                    center=cluster.getCentroid()
                    currentDistance=point.distance(center)
                    if currentDistance<smallestDistance:
                        bestCenter=center
                        smallestDistance=currentDistance
                avgTotalErrorHoldout+=smallestDistance**2
            holdoutsetavg.append(avgTotalErrorHoldout/float(len(holdoutPoints)))
    for number in range(len(kvals)):
          holdoutsetavg[number]/=float(numTrials)
          trainingsetavg[number]/=float(numTrials)
          
    plot1,=pylab.plot(kvals,trainingsetavg)
    plot2,=pylab.plot(kvals,holdoutsetavg)
    pylab.legend(('Training', 'Holdout'))
    pylab.title('kvals vs. Avg Error in Training/Holdout Sets')
    pylab.xlabel('kvals')
    pylab.ylabel('Average Error')
    pylab.show()

kvals=range(5,76,10)
          
# Problem 3: k-means and Individual Counties

def findCountyCluster(points, county, k, cutoff = 0.1):
    '''
    Runs k-means clustering over points 3 times with the given k 
    and cutoff values. Each time the clustering is run, this function
    prints out the cluster that contains the specified county.

    points: a list of Point objects
    county: a string, the county we wish to examine
    k: int, the number of clusters we wish to use
    cutoff: float     
    '''
    for time in range(3):
        (clusterList, diameter)=kmeans(points, k, cutoff, County, minIters = 3, maxIters = 100, toPrint = True)
        for cluster in clusterList:
            print cluster
            break #we break so it doesn't go through the rest of the list
        
County.equal_weights(0)
County.set_weight(County.FarmAcres , 1.0)
County.set_weight(County.PopDensity, .5)

# Problem 4: Predicting Percentage of College Graduates with k-means

def graphPredictionErr(points, kvals, cutoff = 0.1):
    """    
    Given input points and a list of kvals, should cluster on the
    appropriate weight vectors and graph the error in the resulting
    predictions, as described in Problem 4.

    points: a list of Point objects
    kvals: a list of k values (integers)
    cutoff: float     
    """
    # TODO
    kvals=range(5,76,10)
    County.equal_weights(0)
    County.set_weight(County.HomeValue , 1.0)
    County.set_weight(County.Income, 1.0)
    County.set_weight(County.Poverty , 1.0)
    County.set_weight(County.PrcntHSgrads, 1.0)
    County.set_weight(County.Unemployed , 1.0)

    goodCVList=[]
    for k in kvals:
        goodCVsum=0
        (clusterList, diameter)=kmeans(points, k, cutoff, County, minIters = 3, maxIters = 100, toPrint = True)      
        for cluster in clusterList:
            goodPoints=cluster.getPoints()
            goodCVsum+=coefficientVariation(goodPoints, County.PrcntCollege)
        goodCVList.append(float(goodCVsum)/len(clusterList))
    

    County.equal_weights(0)
    County.set_weight(County.PopChange , 1.0)
    County.set_weight(County.Prcnt65, 1.0)
    County.set_weight(County.Below18 , 1.0)
    County.set_weight(County.LifeExpectancy, 1.0)
    County.set_weight(County.PrcntBelow18 , 1.0)

    badCVList=[]
    for k in kvals:
        badCVsum=0
        (clusterList, diameter)=kmeans(points, k, cutoff, County, minIters = 3, maxIters = 100, toPrint = True)      
        for cluster in clusterList:
            badPoints=cluster.getPoints()
            badCVsum+=coefficientVariation(badPoints,County.PrcntCollege)
        badCVList.append(float(badCVsum)/len(clusterList))

    plot1,=pylab.plot(kvals,goodCVList)
    plot2,=pylab.plot(kvals,badCVList)
    pylab.legend(('Good Categories', 'Bad Categories'))
    pylab.title('kvals vs. CV ')
    pylab.xlabel('kvals')
    pylab.ylabel('CV mean')
    pylab.show()
    

    
    #I made a helper function to calculate the CV
def coefficientVariation(points, dimension):
    global PrcntCollege#so that we can get it from another function
    pointList=[]
    for point in points:
        pointList.append(point.getOriginalAttr(dimension))
        #Returns the value of this point's unnormialized attribute for the given dimension.
    sumPointList=sum(pointList)
    mean=sumPointList/float(len(pointList))
    pointSum=0.0#so its a float from begining
    for point in pointList:
        pointSum+=(point-mean)**2
    standardDeviation=math.sqrt(pointSum/len(pointList))
    return standardDeviation/mean

