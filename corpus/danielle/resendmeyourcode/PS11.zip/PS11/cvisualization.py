# 6.00 Pset 11
# cvisualization.py

import pylab, random, string, copy, math, time
from cluster import *
import matplotlib.pyplot as plt
    
def visual_kmeans(figure, subplot, points, k, pointType, dimA, dimB,\
                  delay=1, cutoff=0.1, minIters = 3, maxIters = 100):
    """
    Computes and visually displays the process of two-dimensional k-means 
     clustering, updating the display with each iteration after delay seconds.

    figure: an instance of plt.figure()
    subplot: an instance of figure.add_subplot

    points: a list of points
    k: the number of clusters; k must be between 1 and 6
    pointType: the class name of the points.

    dimA: the first dimension to cluster on.
    dimB: the second dimension to cluster on.
    delay: float, the number of seconds to delay each animation frame. 0.5-4 seconds
     is probably good.
     
    cutoff: the maximum distance between the new centroids and the old
        centroids below which the iteration can stop (because the clusters
        are stable enough).
    minIters: minimum number of iterations
    maxIters: maximum number of iterations

    return: a list of k clusters and the diameter of the least coherent cluster 
    """
    
    # For visualization purposes, we cannot visualize more than 6 clusters.
    assert  k > 0 and k <= 6, "k must be between 1 and 6; got: " + str(k)
    

    # Get k randomly chosen initial centroids
    initialCentroids = random.sample(points, k)
    clusters = []

    # Create a singleton cluster for each centroid
    for c in initialCentroids:
        clusters.append(Cluster([c], pointType))
    numIters = 0
    biggestChange = cutoff

    # ******** Animation Helper Code *********
    # Provide colors for up to 6 clusters
    colors = ['r','g','b','#CCCC00','#CC00CC','#00CCCC']
    # Create x and y coordinates from the two specified attributes
    init_x = [point.getAttr(dimA) for point in points]
    init_y = [point.getAttr(dimB) for point in points]
    # Plot the points
    subplot.plot(init_x, init_y, 'c.')
    subplot.axis('equal')
    plt.title('k = ' + str(k) + ', numIters = ' + str(numIters))
    variables = ('HomeValue','Income','Poverty','PopDensity',\
             'PopChange','Prcnt65+','Below18','PrcntFemale',\
             'PrcntHSgrads','PrcntCollege','Unemployed','PrcntBelow18',\
             'LifeExpectancy','FarmAcres')
    plt.xlabel(variables[dimA])
    plt.ylabel(variables[dimB])
    figure.canvas.draw()
    time.sleep(delay)
    # ******** End Of Animation Helper Code *********

    while (biggestChange >= cutoff and numIters < maxIters) or numIters < minIters:
        # Create a list containing k empty lists, each representing
        # the points inside the new clusters
        newClusterPoints = []
        for i in range(k):
            newClusterPoints.append([])
        for p in points:
            # Find the centroid closest to p
            smallestDistance = p.distance(clusters[0].getCentroid())
            index = 0
            for i in range(k):
                distance = p.distance(clusters[i].getCentroid())
                if distance < smallestDistance:
                    smallestDistance = distance
                    index = i
            # Add p to the list of points for the appropriate cluster
            newClusterPoints[index].append(p)        
            
        # Upate each cluster and record how much the centroid has changed
        biggestChange = 0.0
        for i in range(k):           
            change = clusters[i].update(newClusterPoints[i])
            biggestChange = max(biggestChange, change)

            # ******** Animation Helper Code *********
            x0 = clusters[i].getCentroid().getAttr(dimA)
            y0 = clusters[i].getCentroid().getAttr(dimB)
            subplot.plot([x0],[y0],'ro')
            # ******** End Of Animation Helper Code *********

        numIters += 1

        # ******** Animation Helper Code *********
        figure.canvas.draw()
        time.sleep(delay)

        subplot.clear()
        for i in range(k):
            cluster = clusters[i]
            col = colors[i%len(colors)]
            x0 = cluster.getCentroid().getAttr(dimA)
            y0 = cluster.getCentroid().getAttr(dimB)
            for point in cluster.getPoints():
                x = point.getAttr(dimA)
                y = point.getAttr(dimB)
                line = pylab.Line2D([x0, x],[y0, y], color=col)
                subplot.add_line(line)
            subplot.plot([x0],[y0], 'o', color='#FFFF00') #adds the centroid
            subplot.annotate(len(cluster.getPoints()), (x0+0.01, y0+0.01), weight='bold')
            
        plt.title('k = ' + str(k) + ', numIters = ' + str(numIters))
        plt.xlabel(variables[dimA])
        plt.ylabel(variables[dimB])
        figure.canvas.draw()
        time.sleep(delay)
        # ******** End Of Animation Helper Code *********
        
    #Calculate the diameter of the least coherent cluster
    maxDist = 0.0
    for c in clusters:
        for p in c.getPoints():
            if p.distance(c.getCentroid()) > maxDist:
                maxDist = p.distance(c.getCentroid())
    print 'Number of iterations =', numIters, 'Max Diameter =', maxDist, '\n'
    return clusters, maxDist

