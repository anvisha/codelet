#Problem Set 0
#Name: Danielle Chow
#Collaborators: Conner Fromknecht and Carolina Lopez-Trevino
#Time Spent: 0:30
#
x=raw_input('Enter your date of birth: ')
y=raw_input('Enter your last name: ')
print y + ' ' + x
